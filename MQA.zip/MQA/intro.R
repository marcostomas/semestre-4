msg <- "Fala, Vagabundo!" #tipo: character
bool <- TRUE #logical
numero <- 2 #numeric
numeroInt <- 2L #integer
numeroComplexo <- 2+5i #complex
stringRaw <- charToRaw(msg) #raw (bit do caracter)

print(msg)
print(class(msg))

print(bool)
print(class(bool))

print(numero)
print(class(numero))

print(numeroInt)
print(class(numeroInt))

print(numeroComplexo)
print(class(numeroComplexo))

print(stringRaw) # Saída: 46 61 6c 61 2c 20 56 61 67 61 62 75 6e 64 6f 21
print(class(stringRaw))

# Para rodar o código via CL, use Rscript <caminho do arquivo>
# É possível fazer atribuições de duas formas: "<-" e "="

x = 10
y = 5

a = 10
b = 3

print(x + y)
print(x - y)
print(x * y)
print(x / y)
print(x ^ y) # potência. Saída: 1e+05
print(x %% y) # resto. Saída: 0
print(a %% b) # resto. Saída: 1
print(x %/% y) # quociente inteiro. Saída: 2
print(a %/% b) # quociente inteiro. Saída: 3

# Operadores relacionais são iguais ao de C e Java, isto é: <, >, ==, !=, <=, >=

print(5 == "5") # Saída: TRUE. O tipo não é verificado, como em Java e C, mas o conteúdo é validado.
print(5L == "5L") # Saída: FALSE
print(5L == "5") # Saída: TRUE

# Os operadores lógicos também funcionam de forma semelhante a C e Java: ! (negação), && (e), || (ou)
# Recomendo instalar esta extensão para VS Code: https://marketplace.visualstudio.com/items?itemName=REditorSupport.r
# Ou instalar o RStudio: https://posit.co/download/rstudio-desktop/

# Para saber mais como funciona os pacotes e a instalação de pacotes em R, veja:
# https://cran.r-project.org/doc/manuals/r-release/R-intro.html
# https://cran.r-project.org/doc/manuals/r-release/R-admin.html#Installing-packages
# https://www.dataquest.io/blog/install-package-r/

# O operador duplo dois-pontos (::) seleciona as definições (de funções) em um namespace específico, desde que elas sejam exportadas.
# Por exemplo, em R a função t() [função transposta] é possível de ser usada globalmente e está definada no namespace "base", mas
# caso o usuário queira definir sua própria função t(), é possível invocar a função t() global desta forma: "base::t" 

# O operador triplo dois-pontos (:::) funciona de forma semelhante ao operador (::), mas o operador triplo permite o uso de objetos
# escondidos. O uso do operador triplo não é tão comum. É possível utilizar a função getAnywhere() para desempenhar a mesma função
# que o operador triplo.

#library() # Mostra todos os pacotes instalados
#search() # Mostra todos os pacotes carregados
#loadedNamespaces() # Mostra os namespaces. Namespaces são semelhantes às classes do Java

#R.home(component = "home") # Mostra o locar de instalação do R

#getCRANmirrors(all = FALSE, local.only = FALSE) # Mostra os mirrors (repositório disponíveis para download) disponíveis
#chooseCRANmirror(graphics = getOption("menu.text"), ind = NULL, local.only = FALSE) # Veja https://www.rdocumentation.org/packages/utils/versions/3.6.2/topics/chooseCRANmirror