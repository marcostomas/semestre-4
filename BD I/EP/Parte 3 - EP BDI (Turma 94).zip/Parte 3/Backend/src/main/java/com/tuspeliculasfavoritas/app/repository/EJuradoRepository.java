package com.tuspeliculasfavoritas.app.repository;

import com.tuspeliculasfavoritas.app.model.EJurado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EJuradoRepository extends JpaRepository<EJurado, String> {
}
