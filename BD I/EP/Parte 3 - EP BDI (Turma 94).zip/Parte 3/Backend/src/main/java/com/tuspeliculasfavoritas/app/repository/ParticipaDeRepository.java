package com.tuspeliculasfavoritas.app.repository;


import com.tuspeliculasfavoritas.app.model.ParticipaDe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParticipaDeRepository extends JpaRepository<ParticipaDe, String> {
}
